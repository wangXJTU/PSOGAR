#ifndef __HEURISTIC_H__
#define __HEURISTIC_H__

#include "resource.h"
#include "task.h"

int ff();
int ffd();
int edf();
int sjf();


void fin_overall(struct task *ptask, float ft);
void fin_dev(struct task * ptask, float ft);
void fin_edge(struct task * ptask, float ft);
void fin_cloud(struct task * ptask, float ft);

#endif
