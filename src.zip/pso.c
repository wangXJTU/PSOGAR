#include <string.h>
#include <stdlib.h> 
#include <time.h>
#include <math.h>


#include "pso.h"
#include "include.h"

void init_vel()
{
	int i, itask;
	srand(time(NULL));
	for(i=0; i<num_pop; i++)
	{
		for(itask=0; itask<num_task; itask++)
		{
			//-num_cores/2 ~ num_cores/2
			vel[i][itask] = 1.0 * rand() / RAND_MAX * code_max[itask] - code_max[itask] / 2;
		}
	}
}

float pso(void init_pop(float (*fitness)(int *)), float (*fitness)(int *), 
void (*mu)(int *, int *))
{
	int ipop, iter, itask;
	float w;
	if(init_pop)
		init_pop(fitness);
	memset(gb_pop, 0, MAX_TASK * sizeof(int));
	gb_fit = 0.0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(gb_fit < fit[ipop])
		{
			gb_fit = fit[ipop];
			memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
		}
	}
	memcpy(pb_fit, fit, MAX_POP * sizeof(float));
	memcpy(pb_pop, pop, MAX_POP * MAX_TASK * sizeof(int));
	
	for(iter=0; iter<MAX_ITE; iter++)
	{
		w = w_min + (w_max - w_min) *  (MAX_ITE-iter) / MAX_ITE;
		for(ipop=0; ipop<num_pop; ipop++)
		{
			for(itask=0; itask<num_task; itask++)
			{
				vel[ipop][itask] = vel[ipop][itask] * w 
						+ acc * ((pb_pop[ipop][itask] - pop[ipop][itask]) * rand() / RAND_MAX
							+ (gb_pop[itask] - pop[ipop][itask]) * rand() / RAND_MAX);
				pop[ipop][itask] = round(pop[ipop][itask] + vel[ipop][itask]);
				if(pop[ipop][itask] < 0)
					pop[ipop][itask] = 0;
				else if(pop[ipop][itask] >= code_max[itask])
					pop[ipop][itask] = code_max[itask]-1;
			}
			fit[ipop] = fitness(pop[ipop]);
			if(pb_fit[ipop] < fit[ipop])
			{
				pb_fit[ipop] = fit[ipop];
				memcpy(pb_pop[ipop], pop[ipop], MAX_TASK * sizeof(int));
			}
			
		}
		if(mu)
		{
			for(ipop=0; ipop<num_pop; ipop++)
			{
				if(rand() < RAND_MAX * prob_mu)
				{
					mu(pop[ipop], pop[ipop]);
					fit[ipop] = fitness(pop[ipop]);
				}
				if(pb_fit[ipop] < fit[ipop])
				{
					pb_fit[ipop] = fit[ipop];
					memcpy(pb_pop[ipop], pop[ipop], MAX_TASK * sizeof(int));
				}
			}
		}
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(gb_fit < pb_fit[ipop])
			{
				gb_fit = pb_fit[ipop];
				memcpy(gb_pop, pb_pop[ipop], MAX_TASK * sizeof(int));
			}
		}
	}
	fitness(gb_pop);
	return gb_fit;
}


/**cognation (binary):
		00	-	no
		01	-	self
		10	-	social
		11	-	both
**/
float psoga(void init_pop(float (*fitness)(int *)),
float (*fitness)(int *), 
void (*cross)(int *, int *, int *, int *), 
void (*mu)(int *, int *),
int cog)
{
	int ipop, iter, par, ioff;
	if(init_pop)
		init_pop(fitness);
	memset(gb_pop, 0, MAX_TASK * sizeof(int));
	gb_fit = 0.0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(gb_fit < fit[ipop])
		{
			gb_fit = fit[ipop];
			memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
		}
	}
	memcpy(pb_fit, fit, MAX_POP * sizeof(float));
	memcpy(pb_pop, pop, MAX_POP * MAX_TASK * sizeof(int));
	
	for(iter=0; iter<MAX_ITE; iter++)
	{
		//crossover
		for(ipop=0; ipop<num_pop; ipop++)
		{
			num_off = 0;
			if(rand() < RAND_MAX * prob_cross)
			{
				do{
					par = rand() % num_pop;
				}while(par == ipop);
				cross(pop[ipop], pop[par], pop[num_pop+num_off], pop[num_pop+num_off+1]);
				num_off += 2;
			}
			if((cog & 1) && (rand() < RAND_MAX * prob_cross))
			{
				cross(pop[ipop], pb_pop[ipop], pop[num_pop+num_off], pop[num_pop+num_off+1]);
				num_off += 2;
			}
			if((cog & 2) && (rand() < RAND_MAX * prob_cross))
			{
				cross(pop[ipop], gb_pop, pop[num_pop+num_off], pop[num_pop+num_off+1]);
				num_off += 2;
			}
			int max_off = -1;
			int max_fit = 0;
			for(ioff=num_pop; ioff<num_pop + num_off; ioff++)
			{
				fit[ioff] = fitness(pop[ioff]);
				if(max_fit < fit[ioff])
				{
					max_fit = fit[ioff];
					max_off = ioff;
				}
				if(pb_fit[ioff] < fit[ioff])
				{
					pb_fit[ioff] = fit[ioff];
					memcpy(pb_pop[ioff], pop[ioff], MAX_TASK * sizeof(int));
					if(gb_fit < fit[ioff])
					{
						gb_fit = fit[ioff];
						memcpy(gb_pop, pop[ioff], MAX_TASK * sizeof(int));
					}
				}
			}
			if(max_off > 0 )
			{
				fit[ipop] = max_fit;
				memcpy(pop[ipop], pop[max_off], MAX_TASK * sizeof(int));
			}
		}
		
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_mu)
			{
				mu(pop[ipop], pop[ipop]);
				fit[ipop] = fitness(pop[ipop]);
			}
			if(pb_fit[ipop] < fit[ipop])
			{
				pb_fit[ipop] = fit[ipop];
				memcpy(pb_pop[ipop], pop[ipop], MAX_TASK * sizeof(int));
			}
		}
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(gb_fit < pb_fit[ipop])
			{
				gb_fit = pb_fit[ipop];
				memcpy(gb_pop, pb_pop[ipop], MAX_TASK * sizeof(int));
			}
		}
	}
	fitness(gb_pop);
	return gb_fit;
}

