#ifndef __RESOURCE_H__
#define __RESOURCE_H__
#include "include.h"
#include "location.h"
#include "task.h"

struct device{
	int core;
	float ghz; //per core

	//location
	struct edge *edge;
	struct location loc;

	struct task *tasks[MAX_CORE][MAX_TASK]; //task assignment
	float ft[MAX_CORE];
	float ft_in[MAX_CORE];
};
extern struct device devs[MAX_DEVICE];
extern int num_dev;

struct edge{
	int core; //number of cores
	float ghz; //ghz for each core
	float kbps;//downlink: dev --> edge
	float kbps_up;//downlink: edge --> dev

	struct location loc;
	
	struct task *tasks[MAX_CORE][MAX_TASK]; //task assignment
	float ft[MAX_CORE];
	float ft_in[MAX_CORE];
};

extern struct edge edges[MAX_EDGE];
extern int num_edge;

struct vm_type{
	int core; //number of cores
	float ghz; //ghz for each core
	float kbps;//downlink: dev/edge --> cloud
	float kbps_up;//downlink: cloud --> dev/edge

	float price; // $ per hour
};

extern struct vm_type vm_types[MAX_VM_TYPE];
extern int num_vm_type;

struct vm{
	struct vm_type *vt;
	
	struct task *tasks[MAX_CORE][MAX_TASK]; //task assignment
	float ft[MAX_CORE];
	float ft_in[MAX_CORE];
};
extern struct vm vms[MAX_VM];
extern int num_vm;

void init_dev();
void init_edge();
void init_vm_type();

#endif
