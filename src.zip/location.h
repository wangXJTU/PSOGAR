#ifndef __LOCATION_H__
#define __LOCATION_H__

// [0, MAX_LOC] * [0, MAX_LOC]
#define MAX_LOC 100

struct location{
	float x; //longitude, or X-coordinate
	float y; //latitude, or Y-coordinate
};


float distance(struct location *loc1, struct location *loc2);

#endif
