#ifndef __RESULT_H__
#define __RESULT_H__

struct result{
	int num;
	float ghz;
	float kb;
	float kb_out;
	
	int fin_num;
	float fin_ghz;
	float fin_kb;
	float fin_kb_out;
	float ft;
	float use; //used computing resource
	
	int dev_num;
	float dev_ghz;
	float dev_kb;
	float dev_kb_out;
	float dev_ft;
	float dev_use;
	
	int edge_num;
	float edge_ghz;
	float edge_kb;
	float edge_kb_out;
	float edge_ft;
	float edge_use;
	
	int cloud_num;
	float cloud_ghz;
	float cloud_kb;
	float cloud_kb_out;
	float cloud_ft;
	float cloud_use;
};

extern struct result rst;
void print_head();
void print_rst(char *);

#endif
