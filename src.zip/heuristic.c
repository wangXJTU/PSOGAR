#include "heuristic.h"

#include "result.h"

void fin_overall(struct task *ptask, float ft)
{
	rst.fin_num++;
	rst.fin_ghz += ptask->ghz;
	rst.fin_kb += ptask->kb;
	rst.fin_kb_out += ptask->kb_out;
	if(rst.ft < ft)
		rst.ft = ft;
}

void fin_dev(struct task *ptask, float ft)
{
	fin_overall(ptask, ft);
	rst.dev_num++;
	rst.dev_ghz += ptask->ghz;
	rst.dev_kb += ptask->kb;
	rst.dev_kb_out += ptask->kb_out;
	if(rst.dev_ft < ft)
		rst.dev_ft = ft;
}


void fin_edge(struct task *ptask, float ft)
{
	fin_overall(ptask, ft);
	rst.edge_num++;
	rst.edge_ghz += ptask->ghz;
	rst.edge_kb += ptask->kb;
	rst.edge_kb_out += ptask->kb_out;
	if(rst.edge_ft < ft)
		rst.edge_ft = ft;
}

void fin_cloud(struct task *ptask, float ft)
{
	fin_overall(ptask, ft);
	rst.cloud_num++;
	rst.cloud_ghz += ptask->ghz;
	rst.cloud_kb += ptask->kb;
	rst.cloud_kb_out += ptask->kb_out;
	if(rst.cloud_ft < ft)
		rst.cloud_ft = ft;
}

int ff()
{
	int itask, icore, ivtype, ivm, idev, iedge;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	struct vm_type *pvtype;
	struct vm *pvm;
	float ft = 0.0, ft_in = 0.0;
	for(itask=0; itask<num_task; itask++)
	{
		ptask = tasks + itask;
		
		//device
		pdev = ptask->dev;
		for(icore=0; icore<pdev->core; icore++)
		{
			ft = pdev->ft[icore] + ptask->ghz / pdev->ghz;
			if(ft <= ptask->dl)
			{
				pdev->ft[icore] = ft;
				fin_dev(ptask, ft);
				goto next_task;
			}
		}
		//edge
		pedge = pdev->edge;
		for(icore=0; icore<pedge->core; icore++)
		{
			ft_in = pedge->ft_in[icore] + ptask->kb * 8 * 1024 / pedge->kbps / 1000;
			if(ft_in > pedge->ft[icore])
				ft = ft_in + ptask->ghz / pedge->ghz;
			else
				ft = pedge->ft[icore] + ptask->ghz / pedge->ghz;
			if(ft <= ptask->dl)
			{
				pedge->ft_in[icore] = ft_in;
				pedge->ft[icore] = ft;
				fin_edge(ptask, ft);
				goto next_task;
			}
		}
		//cloud
		//rented VM
		for(ivm=0; ivm<num_vm; ivm++)
		{
			pvm = vms + ivm;
			pvtype = pvm->vt;
			for(icore=0; icore<pvtype->core; icore++)
			{
				ft_in = pvm->ft_in[icore] + ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
				if(ft_in > pvm->ft[icore])
					ft = ft_in + ptask->ghz / pvtype->ghz;
				else
					ft = pvm->ft[icore] + ptask->ghz / pvtype->ghz;
				if(ft <= ptask->dl)
				{
					pvm->ft_in[icore] = ft_in;
					pvm->ft[icore] = ft;
					fin_cloud(ptask, ft);
					goto next_task;
				}
			}
		}
		
		//new VM
		for(ivtype=0; ivtype<num_vm_type; ivtype++)
		{
			pvtype = vm_types + ivtype;
			ft_in = ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
			ft = ft_in + ptask->ghz / pvtype->ghz;
			if(ft <= ptask->dl)
			{
				pvm = vms + num_vm;
				num_vm++;
				
				pvm->vt = pvtype;
				pvm->ft_in[0] = ft_in;
				pvm->ft[0] = ft;
				fin_cloud(ptask, ft);
				goto next_task;
			}
		}
		
	next_task:
		;
	}

	//cumulating resource used
	for(idev=0; idev<num_dev; idev++)
	{
		pdev = devs + idev;
		ft = pdev->ft[0];
		for(icore=1; icore<pdev->core; icore++)
		{
			if(ft < pdev->ft[icore])
				ft = pdev->ft[icore];
		}
		rst.use += ft * pdev->ghz * pdev->core;
		rst.dev_use += ft * pdev->ghz * pdev->core;
	}

	for(iedge=0; iedge<num_edge; iedge++)
	{
		pedge = edges + iedge;
		ft = pedge->ft[0];
		for(icore=1; icore<pedge->core; icore++)
		{
			if(ft < pedge->ft[icore])
				ft = pedge->ft[icore];
		}
		rst.use += ft * pedge->ghz * pedge->core;
		rst.edge_use += ft * pedge->ghz * pedge->core;
	}

	for(ivm=0; ivm<num_vm; ivm++)
	{
		pvm = vms + ivm;
		ft = pvm->ft[0];
		for(icore=1; icore<pvm->vt->core; icore++)
		{
			if(ft < pvm->ft[icore])
				ft = pvm->ft[icore];
		}
		rst.use += ft * pvm->vt->ghz * pvm->vt->core;
		rst.cloud_use += ft * pvm->vt->ghz * pvm->vt->core;
	}

	return rst.fin_num;
}

int ffd()
{
	sort_task_ghz_dec();
	return ff();
}

int edf()
{
	sort_task_deadline_inc();
	return ff();
}


int sjf()
{
	sort_task_ghz_inc();
	return ff();
}

