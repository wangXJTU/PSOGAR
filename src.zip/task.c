#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "task.h"
#include "result.h"

struct task tasks[MAX_TASK];
int num_task = MAX_TASK;

void init_task()
{
	int i;
	memset(tasks, 0, MAX_TASK * sizeof(struct task));
	memset(&rst, 0, sizeof(struct result));
	srand((unsigned)time(NULL));
	float alpha = 1; //task size
	rst.num = num_task;
	for(i=0; i<num_task; i++)
	{
		tasks[i].ghz = (0.7 * rand() / (RAND_MAX + 1.0) + 0.5) * alpha;// [0.5 ~ 1.2] GHz * α
		rst.ghz += tasks[i].ghz;
		tasks[i].kb = (4.5 * rand() / (RAND_MAX + 1.0) + 1.5) * alpha * 1024; // [1.5 ~ 6] MB * α.
		rst.kb += tasks[i].kb;
		tasks[i].kb_out = 0;
		rst.kb_out += tasks[i].kb_out;
		tasks[i].dl = (4 * rand() / (RAND_MAX + 1.0) + 1) * alpha; // 1-5 s * α
		tasks[i].dev = devs + rand() % num_dev;
	}
}

int compare_dl_inc(const void *p1, const void *p2)
{
	struct task *tsk1, *tsk2;
	tsk1 = (struct task *)p1;
	tsk2 = (struct task *)p2;
	return (int)(tsk1->dl - tsk2->dl);
}
void sort_task_deadline_inc()
{
	qsort(tasks, num_task, sizeof(struct task), compare_dl_inc);
}


int compare_ghz_dec(const void *p1, const void *p2)
{
	struct task *tsk1, *tsk2;
	tsk1 = (struct task *)p1;
	tsk2 = (struct task *)p2;
	return (int)((tsk2->ghz - tsk1->ghz)*100);
}
void sort_task_ghz_dec()
{
	qsort(tasks, num_task, sizeof(struct task), compare_ghz_dec);
}


int compare_ghz_inc(const void *p1, const void *p2)
{
	struct task *tsk1, *tsk2;
	tsk1 = (struct task *)p1;
	tsk2 = (struct task *)p2;
	return (int)((tsk1->ghz - tsk2->ghz)*100);
}
void sort_task_ghz_inc()
{
	qsort(tasks, num_task, sizeof(struct task), compare_ghz_inc);
}

