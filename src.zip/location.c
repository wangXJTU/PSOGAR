#include <math.h>
#include "location.h"

float distance(struct location *loc1, struct location *loc2)
{
	return sqrt((loc1->x - loc2->x)*(loc1->x - loc2->x) + (loc1->y - loc2->y)*(loc1->y - loc2->y));
}
