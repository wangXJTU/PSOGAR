#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "evolution.h"
#include "heuristic.h"
#include "result.h"

//* 3 for offspring
int pop[MAX_POP*4][MAX_TASK];
float fit[MAX_POP*4];
int pb_pop[MAX_POP][MAX_TASK];
float pb_fit[MAX_POP];
int gb_pop[MAX_TASK]; 
float gb_fit;
int num_pop = MAX_POP;
int num_off = MAX_POP;

float vel[MAX_POP][MAX_TASK];

int ft_ratio[MAX_TASK][3]; // slack time / finish time * 1000, for coding

int code_max[MAX_TASK]; // {cores of device + edge + the cloud} for each task

//for ga
float prob_mu = 0.1;
float prob_cross = 0.5;

//for pso
float acc = 2.0; // a1 = a2 = 2
float w_min = 0.5; //inertia: [w_min, w_max]
float w_max = 1.2; //inertia: [w_min, w_max]

void cal_ft_ratio()
{
	int itask, ivt;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	struct vm_type *pvtype;
	float ft, min_ft;
	for(itask=0; itask<num_task; itask++)
	{
		ptask = tasks + itask;
		pdev = ptask->dev;
		pedge = pdev->edge;
		
		ft = ptask->ghz / pdev->ghz;
		if(ft <= ptask->dl)
			//ft_ratio[itask][0] = (int)(1000 - ft / ptask->dl * 1000);
			ft_ratio[itask][0] = (int)(1000 / ft);
		else
			ft_ratio[itask][0] = 0;
		
		ft = ptask->kb*8*1024 / pedge->kbps/1000 + ptask->ghz / pedge->ghz;
		if(ft <= ptask->dl)
			ft_ratio[itask][1] = (int)(1000 / ft);
		else
			ft_ratio[itask][1] = 0;
		
		min_ft = 0.0;
		for(ivt=0; ivt<num_vm_type; ivt++)
		{
			pvtype = vm_types + ivt;
			ft = ptask->kb*8*1024 / pvtype->kbps/1000 + ptask->ghz / pvtype->ghz;
			if(ft <= ptask->dl && min_ft > ft)
			{
				min_ft = ft;
			}
		}
		if(min_ft > 1e-4)
			ft_ratio[itask][2] = ft_ratio[itask][0];
		else
			ft_ratio[itask][2] = 0;

		ft_ratio[itask][1] += ft_ratio[itask][0];
		ft_ratio[itask][2] += ft_ratio[itask][1];
	}
}

void cal_code_max()
{
	int itask, ivt;
	int fit_vt;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	struct vm_type *pvtype;
	float ft;
	for(itask=0; itask<num_task; itask++)
	{
		ptask = tasks + itask;
		pdev = ptask->dev;
		pedge = pdev->edge;
		fit_vt = 1;
		
		ft = ptask->kb*8*1024 / pedge->kbps/1000 + ptask->ghz / pedge->ghz;
		if(ft > ptask->dl)
			code_max[itask] = pdev->core;
		
		for(ivt=0; ivt<num_vm_type; ivt++)
		{
			pvtype = vm_types + ivt;
			ft = ptask->kb*8*1024 / pvtype->kbps/1000 + ptask->ghz / pvtype->ghz;
			if(ft <= ptask->dl)
			{
				fit_vt = 2;
				break;
			}
		}
		code_max[itask] = (pdev->core + pedge->core) * fit_vt;
	}
}

//ff
float fitness(int code[MAX_TASK])
{
	int itask, icore, ivtype, ivm, idev, iedge;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	struct vm_type *pvtype;
	struct vm *pvm;
	float ft = 0.0, ft_in = 0.0;
	recover();
	for(itask=0; itask<num_task; itask++)
	{
		ptask = tasks + itask;
		pdev = ptask->dev;
		pedge = pdev->edge;
		
		//scheduled to the local device
		// 0 ~ dev core - 1
		if(code[itask] < pdev->core)
		{
			icore = code[itask];
			ft = pdev->ft[icore] + ptask->ghz / pdev->ghz;
			if(ft <= ptask->dl)
			{
				pdev->ft[icore] = ft;
				fin_dev(ptask, ft);
			}
		}
		else if(code[itask] < pdev->core + pedge->core)
		{
		//scheduled to the edge
		// dev core ~ dev core + edge core - 1
			icore = code[itask] - pdev->core;
		
			ft_in = pedge->ft_in[icore] + ptask->kb * 8 * 1024 / pedge->kbps / 1000;
			if(ft_in > pedge->ft[icore])
				ft = ft_in + ptask->ghz / pedge->ghz;
			else
				ft = pedge->ft[icore] + ptask->ghz / pedge->ghz;
			if(ft <= ptask->dl)
			{
				pedge->ft_in[icore] = ft_in;
				pedge->ft[icore] = ft;
				fin_edge(ptask, ft);
			}
		}
		else	//scheduled to the cloud
		{
			//rented VM
			for(ivm=0; ivm<num_vm; ivm++)
			{
				pvm = vms + ivm;
				pvtype = pvm->vt;
				for(icore=0; icore<pvtype->core; icore++)
				{
					ft_in = pvm->ft_in[icore] + ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
					if(ft_in > pvm->ft[icore])
						ft = ft_in + ptask->ghz / pvtype->ghz;
					else
						ft = pvm->ft[icore] + ptask->ghz / pvtype->ghz;
					if(ft <= ptask->dl)
					{
						pvm->ft_in[icore] = ft_in;
						pvm->ft[icore] = ft;
						fin_cloud(ptask, ft);
						goto next_task;
					}
				}
			}
			
			//new VM
			for(ivtype=0; ivtype<num_vm_type; ivtype++)
			{
				pvtype = vm_types + ivtype;
				ft_in = ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
				ft = ft_in + ptask->ghz / pvtype->ghz;
				if(ft <= ptask->dl)
				{
					pvm = vms + num_vm;
					num_vm++;
					
					pvm->vt = pvtype;
					pvm->ft_in[0] = ft_in;
					pvm->ft[0] = ft;
					fin_cloud(ptask, ft);
					goto next_task;
				}
			}
			
		next_task:
			;
		}
	}

	
	//cumulating resource used
	for(idev=0; idev<num_dev; idev++)
	{
		pdev = devs + idev;
		ft = pdev->ft[0];
		for(icore=1; icore<pdev->core; icore++)
		{
			if(ft < pdev->ft[icore])
				ft = pdev->ft[icore];
		}
		rst.use += ft * pdev->ghz * pdev->core;
		rst.dev_use += ft * pdev->ghz * pdev->core;
	}

	for(iedge=0; iedge<num_edge; iedge++)
	{
		pedge = edges + iedge;
		ft = pedge->ft[0];
		for(icore=1; icore<pedge->core; icore++)
		{
			if(ft < pedge->ft[icore])
				ft = pedge->ft[icore];
		}
		rst.use += ft * pedge->ghz * pedge->core;
		rst.edge_use += ft * pedge->ghz * pedge->core;
	}

	for(ivm=0; ivm<num_vm; ivm++)
	{
		pvm = vms + ivm;
		ft = pvm->ft[0];
		for(icore=1; icore<pvm->vt->core; icore++)
		{
			if(ft < pvm->ft[icore])
				ft = pvm->ft[icore];
		}
		rst.use += ft * pvm->vt->ghz * pvm->vt->core;
		rst.cloud_use += ft * pvm->vt->ghz * pvm->vt->core;
	}
	
	return rst.fin_num + rst.fin_ghz / rst.use;
}


//ff
float fitness_resch(int code[MAX_TASK])
{
	int itask, icore, ivtype, ivm, idev, iedge;
	struct task *unsch[MAX_TASK];
	int iunsch = 0;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	struct vm_type *pvtype;
	struct vm *pvm;
	float ft = 0.0, ft_in = 0.0;
	recover();
	for(itask=0; itask<num_task; itask++)
	{
		ptask = tasks + itask;
		pdev = ptask->dev;
		pedge = pdev->edge;
		
		//scheduled to the local device
		// 0 ~ dev core - 1
		if(code[itask] < pdev->core)
		{
			icore = code[itask];
			ft = pdev->ft[icore] + ptask->ghz / pdev->ghz;
			if(ft <= ptask->dl)
			{
				pdev->ft[icore] = ft;
				fin_dev(ptask, ft);
			}
			else
			{
				unsch[iunsch] = ptask;
				iunsch ++;
			}
		}
		else if(code[itask] < pdev->core + pedge->core)
		{
		//scheduled to the edge
		// dev core ~ dev core + edge core - 1
			icore = code[itask] - pdev->core;
		
			ft_in = pedge->ft_in[icore] + ptask->kb * 8 * 1024 / pedge->kbps / 1000;
			if(ft_in > pedge->ft[icore])
				ft = ft_in + ptask->ghz / pedge->ghz;
			else
				ft = pedge->ft[icore] + ptask->ghz / pedge->ghz;
			if(ft <= ptask->dl)
			{
				pedge->ft_in[icore] = ft_in;
				pedge->ft[icore] = ft;
				fin_edge(ptask, ft);
			}
			else
			{
				unsch[iunsch] = ptask;
				iunsch ++;
			}
		}
		else	//scheduled to the cloud
		{
			//rented VM
			for(ivm=0; ivm<num_vm; ivm++)
			{
				pvm = vms + ivm;
				pvtype = pvm->vt;
				for(icore=0; icore<pvtype->core; icore++)
				{
					ft_in = pvm->ft_in[icore] + ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
					if(ft_in > pvm->ft[icore])
						ft = ft_in + ptask->ghz / pvtype->ghz;
					else
						ft = pvm->ft[icore] + ptask->ghz / pvtype->ghz;
					if(ft <= ptask->dl)
					{
						pvm->ft_in[icore] = ft_in;
						pvm->ft[icore] = ft;
						fin_cloud(ptask, ft);
						goto next_task;
					}
				}
			}
			
			//new VM
			for(ivtype=0; ivtype<num_vm_type; ivtype++)
			{
				pvtype = vm_types + ivtype;
				ft_in = ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
				ft = ft_in + ptask->ghz / pvtype->ghz;
				if(ft <= ptask->dl)
				{
					pvm = vms + num_vm;
					num_vm++;
					
					pvm->vt = pvtype;
					pvm->ft_in[0] = ft_in;
					pvm->ft[0] = ft;
					fin_cloud(ptask, ft);
					goto next_task;
				}
			}
			
			unsch[iunsch] = ptask;
			iunsch ++;
			
		next_task:
			;
		}
	}

	for(itask=0; itask<iunsch; itask++)
	{
		ptask = unsch[itask];
		
		//device
		pdev = ptask->dev;
		for(icore=0; icore<pdev->core; icore++)
		{
			ft = pdev->ft[icore] + ptask->ghz / pdev->ghz;
			if(ft <= ptask->dl)
			{
				pdev->ft[icore] = ft;
				fin_dev(ptask, ft);
				goto next_unsch;
			}
		}
		//edge
		pedge = pdev->edge;
		for(icore=0; icore<pedge->core; icore++)
		{
			ft_in = pedge->ft_in[icore] + ptask->kb * 8 * 1024 / pedge->kbps / 1000;
			if(ft_in > pedge->ft[icore])
				ft = ft_in + ptask->ghz / pedge->ghz;
			else
				ft = pedge->ft[icore] + ptask->ghz / pedge->ghz;
			if(ft <= ptask->dl)
			{
				pedge->ft_in[icore] = ft_in;
				pedge->ft[icore] = ft;
				fin_edge(ptask, ft);
				goto next_unsch;
			}
		}
		//cloud
		//rented VM
		for(ivm=0; ivm<num_vm; ivm++)
		{
			pvm = vms + ivm;
			pvtype = pvm->vt;
			for(icore=0; icore<pvtype->core; icore++)
			{
				ft_in = pvm->ft_in[icore] + ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
				if(ft_in > pvm->ft[icore])
					ft = ft_in + ptask->ghz / pvtype->ghz;
				else
					ft = pvm->ft[icore] + ptask->ghz / pvtype->ghz;
				if(ft <= ptask->dl)
				{
					pvm->ft_in[icore] = ft_in;
					pvm->ft[icore] = ft;
					fin_cloud(ptask, ft);
					goto next_unsch;
				}
			}
		}
		
		//new VM
		for(ivtype=0; ivtype<num_vm_type; ivtype++)
		{
			pvtype = vm_types + ivtype;
			ft_in = ptask->kb * 8 * 1024 / pvtype->kbps / 1000;
			ft = ft_in + ptask->ghz / pvtype->ghz;
			if(ft <= ptask->dl)
			{
				pvm = vms + num_vm;
				num_vm++;
				
				pvm->vt = pvtype;
				pvm->ft_in[0] = ft_in;
				pvm->ft[0] = ft;
				fin_cloud(ptask, ft);
				goto next_unsch;
			}
		}
		
	next_unsch:
		;
	}
	
	//cumulating resource used
	for(idev=0; idev<num_dev; idev++)
	{
		pdev = devs + idev;
		ft = pdev->ft[0];
		for(icore=1; icore<pdev->core; icore++)
		{
			if(ft < pdev->ft[icore])
				ft = pdev->ft[icore];
		}
		rst.use += ft * pdev->ghz * pdev->core;
		rst.dev_use += ft * pdev->ghz * pdev->core;
	}

	for(iedge=0; iedge<num_edge; iedge++)
	{
		pedge = edges + iedge;
		ft = pedge->ft[0];
		for(icore=1; icore<pedge->core; icore++)
		{
			if(ft < pedge->ft[icore])
				ft = pedge->ft[icore];
		}
		rst.use += ft * pedge->ghz * pedge->core;
		rst.edge_use += ft * pedge->ghz * pedge->core;
	}

	for(ivm=0; ivm<num_vm; ivm++)
	{
		pvm = vms + ivm;
		ft = pvm->ft[0];
		for(icore=1; icore<pvm->vt->core; icore++)
		{
			if(ft < pvm->ft[icore])
				ft = pvm->ft[icore];
		}
		rst.use += ft * pvm->vt->ghz * pvm->vt->core;
		rst.cloud_use += ft * pvm->vt->ghz * pvm->vt->core;
	}
	
	return rst.fin_num + rst.fin_ghz / rst.use;
}


void init_pop(float (*fitness)(int *))
{
	int i, j;
	cal_code_max();
	for(i=0; i<num_pop; i++)
	{
		for(j=0; j<num_task; j++)
		{
			pop[i][j] = rand() % code_max[j];
		}
		fit[i] = fitness(pop[i]);
	}
}


void init_pop_ratio(float (*fitness)(int *))
{
	int i, j, rv;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	cal_code_max();
	cal_ft_ratio();
	for(i=0; i<num_pop; i++)
	{
		for(j=0; j<num_task; j++)
		{
			if(ft_ratio[j][2] == 0)
				pop[i][j] = 0;
			else
			{
				ptask = tasks + j;
				pdev = ptask->dev;
				pedge = pdev->edge;
				rv = rand();
				if(rv <= RAND_MAX * ft_ratio[j][0] / ft_ratio[j][2])
					pop[i][j] = rv % pdev->core;
				else if(rv <= RAND_MAX * ft_ratio[j][1] / ft_ratio[j][2])
					pop[i][j] = rv % pedge->core + pdev->core;
				else
					pop[i][j] = pedge->core + pdev->core;
			}
		}
		fit[i] = fitness(pop[i]);
	}
}

//uniform
void mu_unif(int par[MAX_TASK], int off[MAX_TASK])
{
	int i;
	for(i=0; i<num_task; i++)
	{
		if(code_max[i] == 1)
			continue;
		if(rand() < RAND_MAX * prob_mu)
		{
		//	do{
				off[i] = rand() % code_max[i];
		//	}while(off[i] == par[i]);
		}
		else
			off[i] = par[i];
	}
}

//uniform
void mu_unif_ratio(int par[MAX_TASK], int off[MAX_TASK])
{
	int i, rv;
	struct task *ptask;
	struct device *pdev;
	struct edge *pedge;
	for(i=0; i<num_task; i++)
	{
		if(0 == ft_ratio[i][2])
			continue;
		if(rand() < RAND_MAX * prob_mu)
		{
			ptask = tasks + i;
			pdev = ptask->dev;
			pedge = pdev->edge;
			//do{
				rv = rand();
				if(rv <= RAND_MAX * ft_ratio[i][0] / ft_ratio[i][2])
					off[i] = rv % pdev->core;
				else if(rv <= RAND_MAX * ft_ratio[i][1] / ft_ratio[i][2])
					off[i] = rv % pedge->core + pdev->core;
				else
					off[i] = pedge->core + pdev->core;
			//}while(off[i] == par[i]);
		}
		else
			off[i] = par[i];
	}
}

//uniform
void cross_unif(int par1[MAX_TASK], int par2[MAX_TASK], int off1[MAX_TASK], int off2[MAX_TASK])
{
	int i;
	for(i=0; i<num_task; i++)
	{
		if(rand() < RAND_MAX * prob_cross)
		{
			off1[i] = par2[i];
			off2[i] = par1[i];
		}
		else
		{
			off1[i] = par1[i];
			off2[i] = par2[i];
		}
	}
}

//pop[num_pop + num_off] --> pop[num_pop]
void select_roulette()
{
	int new_pop[MAX_POP][MAX_TASK];
	float new_fit[MAX_POP];
	float acc_fit[MAX_POP*4];
	int ipop, igen;
	float rv;
	
	memcpy(new_pop[0], gb_pop, MAX_TASK * sizeof(int));
	new_fit[0] = gb_fit;
	
	acc_fit[0] = fit[0];
	for(ipop=1; ipop<num_pop + num_off; ipop++)
	{
		acc_fit[ipop] = acc_fit[ipop-1] + fit[ipop];
	}
	
	for(igen=1; igen<num_pop; igen++)
	{
		rv = acc_fit[num_pop + num_off -1] * rand() / (RAND_MAX + 1.0);
		for(ipop=0; ipop<num_pop + num_off; ipop++)
		{
			if(rv < acc_fit[ipop])
				break;
		}
		if(ipop >= num_pop + num_off)
			ipop = num_pop + num_off - 1;
		memcpy(new_pop[igen], pop[ipop], MAX_TASK * sizeof(int));
		new_fit[igen] = fit[ipop];
	}
	memcpy(pop, new_pop, MAX_POP * MAX_TASK * sizeof(int));
	memcpy(fit, new_fit, MAX_POP * sizeof(float));
}

float hc(int *code, float fit, int *new_code, float (*fitness)(int *))
{
	int i;
	float new_fit;
	float max_fit = fit;
	int neib[MAX_TASK];
	int result_code[MAX_TASK];
	memcpy(result_code, code, MAX_TASK * sizeof(int));
	for(i=0; i<num_task; i++)
	{
		memcpy(neib, code, MAX_TASK * sizeof(int));
		neib[i] = (code[i] + 1) % code_max[i];
		new_fit = fitness(neib);
		if(max_fit < new_fit)
		{
			max_fit = new_fit;
			memcpy(result_code, neib, MAX_TASK * sizeof(int));
		}
	}
	memcpy(new_code, result_code, MAX_TASK * sizeof(int));
	return max_fit;
}

float rand_pop(float (*fitness)(int [MAX_TASK]))
{
	int ipop;
	init_pop(fitness);
	int max_pop = 0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(fit[max_pop] < fit[ipop])
			max_pop = ipop;
	}
	fitness(pop[max_pop]);
	return max_pop;
}
