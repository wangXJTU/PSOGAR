#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "include.h"
#include "task.h"
#include "resource.h"
#include "location.h"
#include "pso.h"
#include "ga.h"
#include "heuristic.h"
#include "result.h"


struct task tmp_tasks[MAX_TASK];
int tmp_num_task;

struct device tmp_devs[MAX_DEVICE];
int tmp_num_dev = 100;

struct edge tmp_edges[MAX_EDGE];
int tmp_num_edge = 10;

struct vm_type tmp_vm_types[MAX_VM_TYPE];
int tmp_num_vm_type = 10;

struct vm tmp_vms[MAX_VM];
int tmp_num_vm = 0;

struct result tmp_rst;

void init()
{
	init_task();
	init_dev();
	init_edge();
	init_vm_type();
}

void store()
{
	memcpy(tmp_tasks, tasks, MAX_TASK * sizeof(struct task));
	tmp_num_task = num_task;
	
	memcpy(tmp_devs, devs, MAX_DEVICE * sizeof(struct device));
	tmp_num_dev = num_dev;
	
	memcpy(tmp_edges, edges, MAX_EDGE * sizeof(struct edge));
	tmp_num_edge = num_edge;
	
	memcpy(tmp_vm_types, vm_types, MAX_VM_TYPE * sizeof(struct vm_type));
	tmp_num_vm_type = num_vm_type;
	
	memcpy(tmp_vms, vms, MAX_VM * sizeof(struct vm));
	tmp_num_vm = num_vm;
	
	memcpy(&tmp_rst, &rst, sizeof(struct result));
}

void recover()
{
	memcpy(tasks, tmp_tasks, MAX_TASK * sizeof(struct task));
	num_task = tmp_num_task;
	
	memcpy(devs, tmp_devs, MAX_DEVICE * sizeof(struct device));
	num_dev = tmp_num_dev;
	
	memcpy(edges, tmp_edges, MAX_EDGE * sizeof(struct edge));
	num_edge = tmp_num_edge;
	
	memcpy(vm_types, tmp_vm_types, MAX_VM_TYPE * sizeof(struct vm_type));
	num_vm_type = tmp_num_vm_type;
	
	memcpy(vms, tmp_vms, MAX_VM * sizeof(struct vm));
	num_vm = tmp_num_vm;
	
	memcpy(&rst, &tmp_rst, sizeof(struct result));
}

int main()
{
	time_t curtime;
	init();
	store();
	print_head();
	ff();
	print_rst("FF");

	
	recover();
	ffd();
	print_rst("FFD");
	
	recover();
	edf();
	print_rst("EDF");
	
	recover();
	sjf();
	print_rst("SJF");
	
	recover();
	rand_pop(fitness);
	print_rst("RAND");

	time(&curtime);
	fprintf(stderr, "Rand: 1/25, %s", ctime(&curtime));

	recover();
	ga(init_pop, fitness, cross_unif, mu_unif, select_roulette);
	print_rst("GA");

	time(&curtime);
	fprintf(stderr, "GA: 2/25, %s", ctime(&curtime));
	
//	recover();
//	ga_hc(init_pop, fitness, cross_unif, mu_unif, select_roulette);
//	print_rst("GAHC");
//
//	time(&curtime);
//	fprintf(stderr, "GAHC: 2/25, %s", ctime(&curtime));

	recover();
	ga(init_pop_ratio, fitness, cross_unif, mu_unif, select_roulette);
	print_rst("GA_INIT");

	time(&curtime);
	fprintf(stderr, "GA_INIT: 3/25, %s", ctime(&curtime));

	recover();
	ga(init_pop, fitness_resch, cross_unif, mu_unif, select_roulette);
	print_rst("GA_RESCH");

	time(&curtime);
	fprintf(stderr, "GA_RESCH: 4/25, %s", ctime(&curtime));
	
	recover();
	ga_replace(init_pop, fitness, cross_unif, mu_unif);
	print_rst("GA_RPL");

	time(&curtime);
	fprintf(stderr, "GA_RPL: 5/25, %s", ctime(&curtime));
	
	recover();
	ga_replace(init_pop, fitness_resch, cross_unif, mu_unif);
	print_rst("GA_RPL_RESCH");

	time(&curtime);
	fprintf(stderr, "GA_RPL_RESCH: 6/25, %s", ctime(&curtime));
	
/*	recover();
	ga_hc_replace(init_pop, fitness_resch, cross_unif, mu_unif);
	print_rst("GA_RPL_RESCH");

	time(&curtime);
	fprintf(stderr, "GA_HC_RPL_RESCH: 6/25, %s", ctime(&curtime));
	*/
	recover();
	ga_replace(init_pop_ratio, fitness_resch, cross_unif, mu_unif);
	print_rst("GA_RPL_RESCH_INIT");

	time(&curtime);
	fprintf(stderr, "GA_RPL_RESCH_INIT: 7/25, %s", ctime(&curtime));
	
	recover();
	ga(init_pop_ratio, fitness, cross_unif, mu_unif_ratio, select_roulette);
	print_rst("GA_RATIO");

	time(&curtime);
	fprintf(stderr, "GA_RATIO: 8/25, %s", ctime(&curtime));
	
	recover();
	ga(init_pop_ratio, fitness_resch, cross_unif, mu_unif_ratio, select_roulette);
	print_rst("GA_RATIO_RESCH");

	time(&curtime);
	fprintf(stderr, "GA_RATIO_RESCH: 9/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop, fitness, mu_unif);
	print_rst("PSOM");

	time(&curtime);
	fprintf(stderr, "PSOM: 10/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop, fitness_resch, mu_unif);
	print_rst("PSOM_RESCH");

	time(&curtime);
	fprintf(stderr, "PSOM_RESCH: 11/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop_ratio, fitness, mu_unif_ratio);
	print_rst("PSOM_RATIO");

	time(&curtime);
	fprintf(stderr, "PSOM_RATIO: 12/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop_ratio, fitness_resch, mu_unif_ratio);
	print_rst("PSOM_RATIO_RESCH");

	time(&curtime);
	fprintf(stderr, "PSOM_RATIO_RESCH: 13/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop, fitness, NULL);
	print_rst("PSO");

	time(&curtime);
	fprintf(stderr, "PSO: 14/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop, fitness_resch, NULL);
	print_rst("PSO_RESCH");

	time(&curtime);
	fprintf(stderr, "PSO_RESCH: 15/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop_ratio, fitness, NULL);
	print_rst("PSO_INIT");

	time(&curtime);
	fprintf(stderr, "PSO_INIT: 16/25, %s", ctime(&curtime));
	
	recover();
	pso(init_pop_ratio, fitness_resch, NULL);
	print_rst("PSO_INIT_RESCH");

	time(&curtime);
	fprintf(stderr, "PSO_INIT_RESCH: 17/25, %s", ctime(&curtime));
	
	recover();
	ga_pso(init_pop, fitness, cross_unif, mu_unif, select_roulette);
	print_rst("GA_PSO");

	time(&curtime);
	fprintf(stderr, "GA_PSO: 18/25, %s", ctime(&curtime));
	
	recover();
	ga_pso(init_pop, fitness_resch, cross_unif, mu_unif, select_roulette);
	print_rst("GA_PSO_RESCH");

	time(&curtime);
	fprintf(stderr, "GA_PSO_RESCH: 19/25, %s", ctime(&curtime));
	
	recover();
	ga_pso(init_pop_ratio, fitness_resch, cross_unif, mu_unif, select_roulette);
	print_rst("GA_PSO_RESCH_INIT");

	time(&curtime);
	fprintf(stderr, "GA_PSO_RESCH_INIT: 20/25, %s", ctime(&curtime));
	
	recover();
	ga_pso(init_pop_ratio, fitness_resch, cross_unif, mu_unif_ratio, select_roulette);
	print_rst("GA_PSO_RATIO_RESCH_RATIO");

	time(&curtime);
	fprintf(stderr, "GA_PSO_RATIO_RESCH_RATIO: 21/25, %s", ctime(&curtime));
	
	recover();
	psoga(init_pop, fitness, cross_unif, mu_unif, 3);
	print_rst("PSOGA");

	time(&curtime);
	fprintf(stderr, "PSOGA: 22/25, %s", ctime(&curtime));
	
	recover();
	psoga(init_pop, fitness, cross_unif, mu_unif, 1);
	print_rst("PSOGA_self");

	time(&curtime);
	fprintf(stderr, "PSOGA_self: 23/25, %s", ctime(&curtime));
	
	recover();
	psoga(init_pop, fitness, cross_unif, mu_unif, 2);
	print_rst("PSOGA_social");

	time(&curtime);
	fprintf(stderr, "PSOGA_social: 24/25, %s", ctime(&curtime));
	
	recover();
	psoga(init_pop_ratio, fitness, cross_unif, mu_unif, 3);
	print_rst("PSOGA_INIT");

	time(&curtime);
	fprintf(stderr, "PSOGA_INIT: 25/25, %s", ctime(&curtime));

	recover();
	psoga(init_pop, fitness_resch, cross_unif, mu_unif, 3);
	print_rst("PSOGA_RESCH");

	return 0;
}
