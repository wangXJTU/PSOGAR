#ifndef __INCLUDE_H__
#define __INCLUDE_H__

#define MAX_TASK 1000


#define MAX_DEVICE 100

#define MAX_EDGE 50

#define MAX_VM_TYPE 20
#define MAX_VM MAX_TASK

#define MAX_CORE 64



#define MAX_POP 100
#define MAX_ITE 100

void recover();

#endif
