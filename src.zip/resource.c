#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "resource.h"

struct device devs[MAX_DEVICE];
int num_dev = 10;

struct edge edges[MAX_EDGE];
int num_edge = 5;

struct vm_type vm_types[MAX_VM_TYPE];
int num_vm_type = 10;

struct vm vms[MAX_VM];
int num_vm = 0;

void init_dev()
{
	memset(devs, 0, MAX_DEVICE * sizeof(struct device));
	srand((unsigned)time(NULL));
	int i;
	for(i=0; i<num_dev; i++)
	{
		devs[i].core = rand() % 7 + 2; // 2 ~ 8
		devs[i].ghz = 0.7 * rand() / (RAND_MAX + 1.0) + 1.8; //1.8 ~ 2.5
		devs[i].edge = edges + rand() % num_edge;
		devs[i].loc.x = MAX_LOC * rand() / (RAND_MAX + 1.0);
		devs[i].loc.y = MAX_LOC * rand() / (RAND_MAX + 1.0);
	}
}

void init_edge()
{
	memset(edges, 0, MAX_EDGE * sizeof(struct edge));
	srand((unsigned)time(NULL));
	int i;
	for(i=0; i<num_edge; i++)
	{
		edges[i].core = rand() % 29 + 4; // 4 ~ 32
		edges[i].ghz = 1.2 * rand() / (RAND_MAX + 1.0) + 1.8; //1.8 ~ 3.0
		edges[i].kbps = (2 * rand() / (RAND_MAX + 1.0) + 4) * 20000; //100 +- 20Mbps
		edges[i].kbps_up = (9 * rand() / (RAND_MAX + 1.0) + 1) * 1000; //1 ~ 10Mbps
		edges[i].loc.x = MAX_LOC * rand() / (RAND_MAX + 1.0);
		edges[i].loc.y = MAX_LOC * rand() / (RAND_MAX + 1.0);
	}
}


void init_vm_type()
{
	memset(vm_types, 0, MAX_VM_TYPE * sizeof(struct vm_type));
	memset(vms, 0, MAX_VM * sizeof(struct vm));
	srand((unsigned)time(NULL));
	int i;
	for(i=0; i<num_vm_type; i++)
	{
		vm_types[i].core = rand() % 8 + 1; // 1 ~ 8
		vm_types[i].ghz = 1.2 * rand() / (RAND_MAX + 1.0) + 1.8; //1.8 ~ 3.0
		vm_types[i].kbps = (1 * rand() / (RAND_MAX + 1.0) + 1) * 20000; //10 ~ 20Mbps
		vm_types[i].kbps_up = (9 * rand() / (RAND_MAX + 1.0) + 1) * 1000; //1 ~ 10Mbps
		vm_types[i].price = 0.4 * rand() / (RAND_MAX + 1.0) + 0.1; //0.1~0.5
	}
}