#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "ga.h"
#include "pso.h"

float ga(void init_pop(float (*fitness)(int *)),
float (*fitness)(int *), 
void (*cross)(int *, int *, int *, int *), 
void (*mu)(int *, int *),
void (*select)())
{
	int ipop, iter;
	int par;
	init_pop(fitness);
	memset(gb_pop, 0, MAX_TASK * sizeof(int));
	gb_fit = 0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(gb_fit < fit[ipop])
		{
			gb_fit = fit[ipop];
			memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
		}
	}
	for(iter=0; iter<MAX_ITE; iter++)
	{
		num_off = 0;
		//crossover
		//printf("crossover\n");
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_cross)
			{
				do{
					par = rand() % num_pop;
				}while(par == ipop);
				cross(pop[ipop], pop[par], pop[num_pop+num_off], pop[num_pop+num_off+1]);
				
		//		fit[num_pop+num_off] = fitness(pop[num_pop+num_off]);
		//		fit[num_pop+num_off+1] = fitness(pop[num_pop+num_off+1]);
				
				num_off += 2;
			}
		}
		//mutation
		//printf("mutation\n");
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_mu)
			{
				mu(pop[ipop], pop[num_pop+num_off]);
		//		fit[num_pop+num_off] = fitness(pop[num_pop+num_off]);
				num_off ++;
			}
		}
		for(ipop=num_pop; ipop<num_pop + num_off; ipop++)
		{
			fit[ipop] = fitness(pop[ipop]);
			if(gb_fit < fit[ipop])
			{
				gb_fit = fit[ipop];
				memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
			}
		}
		//select
		//printf("select\n");
		select();
	}
	fitness(gb_pop);
	return gb_fit;
}


float ga_hc(void init_pop(float (*fitness)(int *)),
float (*fitness)(int *), 
void (*cross)(int *, int *, int *, int *), 
void (*mu)(int *, int *),
void (*select)())
{
	int ipop, iter;
	int par;
	init_pop(fitness);
	memset(gb_pop, 0, MAX_TASK * sizeof(int));
	gb_fit = 0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(gb_fit < fit[ipop])
		{
			gb_fit = fit[ipop];
			memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
		}
	}
	for(iter=0; iter<MAX_ITE; iter++)
	{
		num_off = 0;
		//crossover
		//printf("crossover\n");
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_cross)
			{
				do{
					par = rand() % num_pop;
				}while(par == ipop);
				cross(pop[ipop], pop[par], pop[num_pop+num_off], pop[num_pop+num_off+1]);
				
		//		fit[num_pop+num_off] = fitness(pop[num_pop+num_off]);
		//		fit[num_pop+num_off+1] = fitness(pop[num_pop+num_off+1]);
				
				num_off += 2;
			}
		}
		//mutation
		//printf("mutation\n");
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_mu)
			{
				mu(pop[ipop], pop[num_pop+num_off]);
		//		fit[num_pop+num_off] = fitness(pop[num_pop+num_off]);
				num_off ++;
			}
		}
		for(ipop=num_pop; ipop<num_pop + num_off; ipop++)
		{
			fit[ipop] = fitness(pop[ipop]);
			if(gb_fit < fit[ipop])
			{
				gb_fit = fit[ipop];
				memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
			}
		}
		//select
		//printf("select\n");
		select();
		for(ipop=0; ipop<num_pop; ipop++)
		{
			fit[ipop] = hc(pop[ipop], fit[ipop], pop[ipop], fitness);
			if(gb_fit < fit[ipop])
			{
				gb_fit = fit[ipop];
				memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
			}
		}
	}
	fitness(gb_pop);
	return gb_fit;
}



//replace replacing select
float ga_hc_replace(void init_pop(float (*fitness)(int *)),
float (*fitness)(int *), 
void (*cross)(int *, int *, int *, int *), 
void (*mu)(int *, int *))
{
	int ipop, iter;
	int par;
	init_pop(fitness);
	memset(gb_pop, 0, MAX_TASK * sizeof(int));
	gb_fit = 0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(gb_fit < fit[ipop])
		{
			gb_fit = fit[ipop];
			memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
		}
	}
	for(iter=0; iter<MAX_ITE; iter++)
	{
		num_off = 0;
		//crossover
		//printf("%d crossover\n", iter);
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_cross)
			{
				do{
					par = rand() % num_pop;
				}while(par == ipop);
				cross(pop[ipop], pop[par], pop[num_pop+num_off], pop[num_pop+num_off+1]);
				
				fit[num_pop+num_off] = fitness(pop[num_pop+num_off]);
				fit[num_pop+num_off+1] = fitness(pop[num_pop+num_off+1]);
				if(fit[num_pop+num_off] < fit[num_pop+num_off+1])
				{
					fit[num_pop+num_off] = fit[num_pop+num_off+1];
					memcpy(pop[num_pop+num_off], pop[num_pop+num_off+1], MAX_TASK * sizeof(int));
				}
				fit[ipop] = fit[num_pop+num_off];
				memcpy(pop[ipop], pop[num_pop+num_off], MAX_TASK * sizeof(int));

				if(gb_fit < fit[ipop])
				{
					gb_fit = fit[ipop];
					memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
				}
			}
		}
		//mutation
		//printf("mutation\n");
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_mu)
			{
				mu(pop[ipop], pop[ipop]);
				fit[ipop] = fitness(pop[ipop]);
				if(gb_fit < fit[ipop])
				{
					gb_fit = fit[ipop];
					memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
				}
			}
		}
		
		for(ipop=0; ipop<num_pop; ipop++)
		{
			fit[ipop] = hc(pop[ipop], fit[ipop], pop[ipop], fitness);
			if(gb_fit < fit[ipop])
			{
				gb_fit = fit[ipop];
				memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
			}
		}
	}
	fitness(gb_pop);
	return gb_fit;
}

//replace replacing select
float ga_replace(void init_pop(float (*fitness)(int *)),
float (*fitness)(int *), 
void (*cross)(int *, int *, int *, int *), 
void (*mu)(int *, int *))
{
	int ipop, iter;
	int par;
	init_pop(fitness);
	memset(gb_pop, 0, MAX_TASK * sizeof(int));
	gb_fit = 0;
	for(ipop=0; ipop<num_pop; ipop++)
	{
		if(gb_fit < fit[ipop])
		{
			gb_fit = fit[ipop];
			memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
		}
	}
	for(iter=0; iter<MAX_ITE; iter++)
	{
		num_off = 0;
		//crossover
		//printf("%d crossover\n", iter);
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_cross)
			{
				do{
					par = rand() % num_pop;
				}while(par == ipop);
				cross(pop[ipop], pop[par], pop[num_pop+num_off], pop[num_pop+num_off+1]);
				
				fit[num_pop+num_off] = fitness(pop[num_pop+num_off]);
				fit[num_pop+num_off+1] = fitness(pop[num_pop+num_off+1]);
				if(fit[num_pop+num_off] < fit[num_pop+num_off+1])
				{
					fit[num_pop+num_off] = fit[num_pop+num_off+1];
					memcpy(pop[num_pop+num_off], pop[num_pop+num_off+1], MAX_TASK * sizeof(int));
				}
				fit[ipop] = fit[num_pop+num_off];
				memcpy(pop[ipop], pop[num_pop+num_off], MAX_TASK * sizeof(int));

				if(gb_fit < fit[ipop])
				{
					gb_fit = fit[ipop];
					memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
				}
			}
		}
		//mutation
		//printf("mutation\n");
		for(ipop=0; ipop<num_pop; ipop++)
		{
			if(rand() < RAND_MAX * prob_mu)
			{
				mu(pop[ipop], pop[ipop]);
				fit[ipop] = fitness(pop[ipop]);
				if(gb_fit < fit[ipop])
				{
					gb_fit = fit[ipop];
					memcpy(gb_pop, pop[ipop], MAX_TASK * sizeof(int));
				}
			}
		}
	}
	fitness(gb_pop);
	return gb_fit;
}


float ga_pso(void init_pop(float (*fitness)(int *)), float (*fitness)(int *), 
void (*cross)(int *, int *, int *, int *), 
void (*mu)(int *, int *),
void (*select)())
{
	ga(init_pop, fitness, cross, mu, select);
	pso(NULL, fitness, NULL);
	fitness(gb_pop);
	return gb_fit;
}

