#include <stdio.h>
#include "result.h"

struct result rst;

void print_head()
{
	printf("Task: %d,\t%.0fGHz,\t%.0fKB\n", rst.num, rst.ghz, rst.kb);
	printf("method\t");
	printf("AR(%%)\t\t\t\t");
	printf("AR_computing(%%)\t\t\t\t");
	printf("AR_data(%%)\t\t\t\t");
	printf("utilization(%%)\t\t\t\t");
	printf("utiData(MB/GHz)\t\t\t\t");
	printf("procEff(THz/s)\t\t\t\t");
	printf("procEff(GB/s)\t\t\t\n");
}

void print_rst(char *method)
{
	printf("%s\t", method);
	
	printf("%.2f\t%.2f\t%.2f\t%.2f\t", 
		1.0 * rst.fin_num / rst.num * 100, 1.0 * rst.dev_num / rst.num * 100,
		1.0 * rst.edge_num / rst.num * 100, 1.0 * rst.cloud_num / rst.num * 100);
	printf("%.4f\t%.4f\t%.4f\t%.4f\t",
		rst.fin_ghz / rst.ghz * 100, rst.dev_ghz / rst.ghz * 100,
		rst.edge_ghz / rst.ghz * 100, rst.cloud_ghz / rst.ghz * 100);
	printf("%.4f\t%.4f\t%.4f\t%.4f\t", 
		rst.fin_kb / rst.kb * 100, rst.dev_kb / rst.kb * 100,
		rst.edge_kb / rst.kb * 100, rst.cloud_kb / rst.kb * 100);
	printf("%.4f\t%.4f\t%.4f\t%.4f\t", 
		rst.fin_ghz/rst.use * 100, rst.dev_ghz/rst.dev_use * 100,
		rst.edge_ghz/rst.edge_use * 100, rst.cloud_ghz/rst.cloud_use * 100);
	printf("%.4f\t%.4f\t%.4f\t%.4f\t", 
		rst.fin_kb/rst.use  / 1024, rst.dev_kb/rst.dev_use / 1024,
		rst.edge_kb/rst.edge_use / 1024, rst.cloud_kb/rst.cloud_use / 1024);
	printf("%.4f\t%.4f\t%.4f\t%.4f\t", 
		rst.fin_ghz/rst.ft * 100/ 1000, rst.dev_ghz/rst.dev_ft * 100/ 1000,
		rst.edge_ghz/rst.edge_ft * 100/ 1000, rst.cloud_ghz/rst.cloud_ft * 100/ 1000);
	printf("%.4f\t%.4f\t%.4f\t%.4f\n", 
		rst.fin_kb/rst.ft / 1024 / 1024 * 100, rst.dev_kb/rst.dev_ft / 1024 / 1024 * 100,
		rst.edge_kb/rst.edge_ft / 1024 / 1024 * 100, rst.cloud_kb/rst.cloud_ft / 1024 / 1024 * 100);
}
