#ifndef __TASK_H__
#define __TASK_H__
#include "include.h"
#include "resource.h"
struct task{
	float ghz; //GHz for computing size / length
	float kb; //input data
	float kb_out; //output data
	float dl; //output data
	
	struct device *dev; //the device initiating the task
};

struct task_stat{
	int num;
	float ghz; //GHz for computing size / length
	float kb; //input data
	float kb_out; //output data
};

extern struct task tasks[MAX_TASK];
extern int num_task;

void init_task();

void sort_task_deadline_inc();

void sort_task_ghz_dec();
void sort_task_ghz_inc();


#endif
