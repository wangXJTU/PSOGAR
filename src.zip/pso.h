#ifndef __PSO_H__
#define __PSO_H__


#include "evolution.h"

float pso(void init_pop(float (*fitness)(int *)), float (*fitness)(int *), 
			void (*mu)(int *, int *));

float psoga(void init_pop(float (*fitness)(int *)),
			float (*fitness)(int *), 
			void (*cross)(int *, int *, int *, int *), 
			void (*mu)(int *, int *),
			int cog);

#endif
