#ifndef __EVOLUTION_H__
#define __EVOLUTION_H__
#include "include.h"

#include "task.h"
#include "resource.h"

extern int pop[MAX_POP*4][MAX_TASK];
extern float fit[MAX_POP*4];
extern int pb_pop[MAX_POP][MAX_TASK];
extern float pb_fit[MAX_POP];
extern int gb_pop[MAX_TASK]; 
extern float gb_fit;
extern int num_pop;
extern int num_off;

extern int code_max[MAX_TASK]; // 0 ~ {cores of device + edge + the cloud} for each task

//for ga
extern float prob_mu;
extern float prob_cross;

//for pso
extern float acc; // a1 = a2 = 2
extern float w_min; //inertia: [w_min, w_max]
extern float w_max; //inertia: [w_min, w_max]

extern float vel[MAX_POP][MAX_TASK];


void init_pop(float (*fitness)(int *));
void init_pop_ratio(float (*fitness)(int *));


float fitness(int code[MAX_TASK]);
float fitness_resch(int code[MAX_TASK]);


void mu_unif(int par[MAX_TASK], int off[MAX_TASK]);
void mu_unif_ratio(int par[MAX_TASK], int off[MAX_TASK]);

void cross_unif(int par1[MAX_TASK], int par2[MAX_TASK], int off1[MAX_TASK], int off2[MAX_TASK]);

void select_roulette();

float hc(int *code, float fit, int *new_code, float (*fitness)(int *));

float rand_pop(float (*fitness)(int [MAX_TASK]));

#endif
