#ifndef __GA_H__
#define __GA_H__
#include "include.h"
#include "evolution.h"


float ga(void init_pop(float (*fitness)(int *)),
			float (*fitness)(int *), 
			void (*cross)(int *, int *, int *, int *), 
			void (*mu)(int *, int *),
			void (*select)());
float ga_hc(void init_pop(float (*fitness)(int *)),
			float (*fitness)(int *), 
			void (*cross)(int *, int *, int *, int *), 
			void (*mu)(int *, int *),
			void (*select)());

float ga_hc_replace(void init_pop(float (*fitness)(int *)),
			float (*fitness)(int *), 
			void (*cross)(int *, int *, int *, int *), 
			void (*mu)(int *, int *));


float ga_replace(void init_pop(float (*fitness)(int *)),
			float (*fitness)(int *), 
			void (*cross)(int *, int *, int *, int *), 
			void (*mu)(int *, int *));

float ga_pso(void init_pop(float (*fitness)(int *)), float (*fitness)(int *), 
			void (*cross)(int *, int *, int *, int *), 
			void (*mu)(int *, int *),
			void (*select)());

#endif
